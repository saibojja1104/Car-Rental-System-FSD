import api from './api';

export interface Booking {
  id: string;
  carId: string;
  userId: string;
  startDate: string;
  endDate: string;
  totalPrice: number;
  status: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED';
  createdAt: string;
  car?: {
    make: string;
    model: string;
    year: number;
    imageUrls: string[];
  };
}

export interface BookingRequest {
  carId: string;
  startDate: string;
  endDate: string;
}

const bookingService = {
  getUserBookings: async (): Promise<Booking[]> => {
    const response = await api.get('/bookings/user');
    return response.data;
  },
  
  createBooking: async (bookingData: BookingRequest): Promise<Booking> => {
    const response = await api.post('/bookings', bookingData);
    return response.data;
  },
  
  cancelBooking: async (id: string): Promise<void> => {
    await api.put(`/bookings/${id}/cancel`);
  },
  
  // Admin functions
  getAllBookings: async (): Promise<Booking[]> => {
    const response = await api.get('/admin/bookings');
    return response.data;
  },
  
  updateBookingStatus: async (id: string, status: Booking['status']): Promise<Booking> => {
    const response = await api.put(`/admin/bookings/${id}/status`, { status });
    return response.data;
  }
};

export default bookingService;