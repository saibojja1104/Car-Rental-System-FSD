import api from './api';

export interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  color: string;
  licensePlate: string;
  dailyRate: number;
  isAvailable: boolean;
  category: string;
  fuelType: string;
  transmission: string;
  seats: number;
  mileage: number;
  features: string[];
  imageUrls: string[];
  description: string;
}

export interface CarFilter {
  category?: string;
  make?: string;
  minPrice?: number;
  maxPrice?: number;
  availableOnly?: boolean;
}

const carService = {
  getAllCars: async (): Promise<Car[]> => {
    const response = await api.get('/cars');
    return response.data;
  },
  
  getCarById: async (id: string): Promise<Car> => {
    const response = await api.get(`/cars/${id}`);
    return response.data;
  },
  
  getFilteredCars: async (filters: CarFilter): Promise<Car[]> => {
    const response = await api.get('/cars/filter', { params: filters });
    return response.data;
  },
  
  // Admin functions
  createCar: async (carData: Omit<Car, 'id'>): Promise<Car> => {
    const response = await api.post('/admin/cars', carData);
    return response.data;
  },
  
  updateCar: async (id: string, carData: Partial<Car>): Promise<Car> => {
    const response = await api.put(`/admin/cars/${id}`, carData);
    return response.data;
  },
  
  deleteCar: async (id: string): Promise<void> => {
    await api.delete(`/admin/cars/${id}`);
  }
};

export default carService;