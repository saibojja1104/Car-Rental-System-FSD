import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Calendar, Shield, MapPin, Clock } from 'lucide-react';
import carService, { Car } from '../services/carService';
import Hero from '../components/home/Hero';
import FeaturedCars from '../components/home/FeaturedCars';
import HowItWorks from '../components/home/HowItWorks';
import Testimonials from '../components/home/Testimonials';

const HomePage = () => {
  const [featuredCars, setFeaturedCars] = useState<Car[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const loadFeaturedCars = async () => {
      try {
        const cars = await carService.getAllCars();
        // Filter for 6 featured cars
        const featured = cars
          .filter(car => car.isAvailable)
          .sort(() => 0.5 - Math.random()) // Simple shuffle
          .slice(0, 6);
        
        setFeaturedCars(featured);
      } catch (error) {
        console.error('Error loading featured cars:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadFeaturedCars();
  }, []);
  
  const benefits = [
    {
      icon: <Calendar className="h-8 w-8 text-orange-500" />,
      title: 'Flexible Booking',
      description: 'Book your car for any duration, from a few hours to weeks or months.'
    },
    {
      icon: <Shield className="h-8 w-8 text-orange-500" />,
      title: 'Insurance Included',
      description: 'Every rental includes comprehensive insurance coverage for your peace of mind.'
    },
    {
      icon: <MapPin className="h-8 w-8 text-orange-500" />,
      title: 'Multiple Locations',
      description: 'Pick up and drop off your rental car at any of our convenient locations.'
    },
    {
      icon: <Clock className="h-8 w-8 text-orange-500" />,
      title: '24/7 Support',
      description: 'Our customer support team is available around the clock to assist you.'
    }
  ];
  
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <Hero />
      
      {/* Featured Cars Section */}
      <FeaturedCars cars={featuredCars} isLoading={isLoading} />
      
      {/* How It Works Section */}
      <HowItWorks />
      
      {/* Benefits Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Why Choose DriveEasy</h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              Experience the best car rental service with benefits designed to make your journey smooth.
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <div className="mb-4">{benefit.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <Testimonials />
      
      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-800 to-indigo-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">Ready to hit the road?</h2>
          <p className="mt-4 text-xl text-blue-100 max-w-3xl mx-auto">
            Find your perfect ride and start your journey today.
          </p>
          <div className="mt-8">
            <Link
              to="/cars"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-900 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white shadow-md transition-all duration-300"
            >
              Browse Cars
              <ChevronRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;