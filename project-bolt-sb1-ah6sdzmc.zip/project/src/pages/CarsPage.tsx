import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, SortAsc, SortDesc } from 'lucide-react';
import carService, { Car, CarFilter } from '../services/carService';
import Button from '../components/ui/Button';
import Loading from '../components/ui/Loading';

const CarsPage = () => {
  const [searchParams] = useSearchParams();
  const [cars, setCars] = useState<Car[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState<CarFilter>({
    category: searchParams.get('category') || undefined,
    make: searchParams.get('make') || undefined,
    minPrice: searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : undefined,
    maxPrice: searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : undefined,
    availableOnly: true
  });
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc'>('price_asc');
  
  useEffect(() => {
    loadCars();
  }, [filters, sortBy]);
  
  const loadCars = async () => {
    try {
      setIsLoading(true);
      const fetchedCars = await carService.getFilteredCars(filters);
      
      // Sort cars based on price
      const sortedCars = [...fetchedCars].sort((a, b) => {
        return sortBy === 'price_asc' 
          ? a.dailyRate - b.dailyRate 
          : b.dailyRate - a.dailyRate;
      });
      
      setCars(sortedCars);
    } catch (error) {
      console.error('Error loading cars:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const toggleSort = () => {
    setSortBy(prev => prev === 'price_asc' ? 'price_desc' : 'price_asc');
  };
  
  if (isLoading) {
    return <Loading message="Loading available cars..." />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Available Cars</h1>
            <p className="mt-2 text-gray-600">
              Find and book your perfect rental car
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-4">
            <Button
              variant="outline"
              icon={<Filter className="h-5 w-5" />}
              onClick={() => {/* Add filter modal/drawer */}}
            >
              Filters
            </Button>
            
            <Button
              variant="outline"
              icon={sortBy === 'price_asc' ? <SortAsc className="h-5 w-5" /> : <SortDesc className="h-5 w-5" />}
              onClick={toggleSort}
            >
              Price {sortBy === 'price_asc' ? 'Low to High' : 'High to Low'}
            </Button>
          </div>
        </div>
        
        {cars.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <Filter className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-lg font-medium text-gray-900">No cars found</h3>
            <p className="mt-1 text-gray-500">Try adjusting your filters to find available cars.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {cars.map((car) => (
              <div
                key={car.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="relative h-48">
                  <img
                    src={car.imageUrls[0] || 'https://images.pexels.com/photos/1213294/pexels-photo-1213294.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'}
                    alt={`${car.make} ${car.model}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-orange-500 text-white text-sm font-semibold px-3 py-1 rounded-full">
                    ${car.dailyRate}/day
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900">
                    {car.make} {car.model}
                  </h3>
                  <p className="text-gray-600 mt-1">{car.year} • {car.category}</p>
                  
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Transmission</p>
                      <p className="font-medium text-gray-900">{car.transmission}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Seats</p>
                      <p className="font-medium text-gray-900">{car.seats}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Fuel Type</p>
                      <p className="font-medium text-gray-900">{car.fuelType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Mileage</p>
                      <p className="font-medium text-gray-900">{car.mileage} km</p>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <Button
                      variant="primary"
                      fullWidth
                      onClick={() => {/* Add booking logic */}}
                    >
                      Book Now
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CarsPage;