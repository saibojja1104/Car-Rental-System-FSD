import { Link } from 'react-router-dom';
import { Car, ArrowLeft } from 'lucide-react';
import Button from '../components/ui/Button';

const NotFoundPage = () => {
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16 bg-gray-50">
      <div className="max-w-md w-full text-center">
        <Car className="h-16 w-16 text-orange-500 mx-auto" />
        
        <h1 className="mt-6 text-3xl font-bold text-gray-900 sm:text-4xl">
          Page Not Found
        </h1>
        
        <p className="mt-3 text-gray-600">
          Oops! It seems like you've taken a wrong turn. The page you're looking for doesn't exist.
        </p>
        
        <div className="mt-10">
          <Link to="/">
            <Button
              variant="primary"
              size="lg"
              icon={<ArrowLeft className="h-5 w-5" />}
            >
              Back to Homepage
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;