import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Calendar, Clock, CreditCard, Car } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import carService from '../services/carService';
import bookingService from '../services/bookingService';
import Button from '../components/ui/Button';
import TextField from '../components/ui/TextField';
import Loading from '../components/ui/Loading';

const BookingPage = () => {
  const { carId } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [car, setCar] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [bookingData, setBookingData] = useState({
    startDate: '',
    endDate: '',
    totalDays: 0,
    totalPrice: 0
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: `/booking/${carId}` } });
      return;
    }
    
    const loadCar = async () => {
      try {
        const carData = await carService.getCarById(carId);
        setCar(carData);
      } catch (error) {
        console.error('Error loading car:', error);
        toast.error('Failed to load car details');
        navigate('/cars');
      } finally {
        setIsLoading(false);
      }
    };
    
    loadCar();
  }, [carId, isAuthenticated, navigate]);
  
  const handleDateChange = (e) => {
    const { name, value } = e.target;
    setBookingData(prev => {
      const newData = { ...prev, [name]: value };
      
      if (newData.startDate && newData.endDate) {
        const start = new Date(newData.startDate);
        const end = new Date(newData.endDate);
        const diffTime = Math.abs(end - start);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        return {
          ...newData,
          totalDays: diffDays,
          totalPrice: diffDays * car.dailyRate
        };
      }
      
      return newData;
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!bookingData.startDate || !bookingData.endDate) {
      toast.error('Please select both start and end dates');
      return;
    }
    
    const startDate = new Date(bookingData.startDate);
    const endDate = new Date(bookingData.endDate);
    
    if (startDate >= endDate) {
      toast.error('End date must be after start date');
      return;
    }
    
    if (startDate < new Date()) {
      toast.error('Start date cannot be in the past');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await bookingService.createBooking({
        carId,
        startDate: bookingData.startDate,
        endDate: bookingData.endDate
      });
      
      toast.success('Booking created successfully!');
      navigate('/dashboard');
    } catch (error) {
      console.error('Booking error:', error);
      toast.error('Failed to create booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (isLoading) {
    return <Loading message="Loading booking details..." />;
  }
  
  if (!car) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Car className="h-12 w-12 text-gray-400 mx-auto" />
          <h2 className="mt-2 text-lg font-medium text-gray-900">Car not found</h2>
          <p className="mt-1 text-gray-500">The car you're looking for doesn't exist.</p>
          <div className="mt-6">
            <Button onClick={() => navigate('/cars')}>
              Back to Cars
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-8">
              <div className="flex items-center justify-between mb-8">
                <h1 className="text-2xl font-bold text-gray-900">Book Your Car</h1>
                <div className="text-orange-500 font-semibold">
                  ${car.dailyRate}/day
                </div>
              </div>
              
              {/* Car Details */}
              <div className="flex items-center mb-8 p-4 bg-gray-50 rounded-lg">
                <img
                  src={car.imageUrls[0]}
                  alt={`${car.make} ${car.model}`}
                  className="w-24 h-24 object-cover rounded-md"
                />
                <div className="ml-4">
                  <h2 className="text-xl font-semibold text-gray-900">
                    {car.make} {car.model}
                  </h2>
                  <p className="text-gray-600">{car.year} • {car.category}</p>
                </div>
              </div>
              
              {/* Booking Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <TextField
                      label="Start Date"
                      type="date"
                      name="startDate"
                      value={bookingData.startDate}
                      onChange={handleDateChange}
                      min={new Date().toISOString().split('T')[0]}
                      required
                      icon={<Calendar className="h-5 w-5 text-gray-400" />}
                    />
                  </div>
                  
                  <div>
                    <TextField
                      label="End Date"
                      type="date"
                      name="endDate"
                      value={bookingData.endDate}
                      onChange={handleDateChange}
                      min={bookingData.startDate || new Date().toISOString().split('T')[0]}
                      required
                      icon={<Calendar className="h-5 w-5 text-gray-400" />}
                    />
                  </div>
                </div>
                
                {/* Booking Summary */}
                {bookingData.totalDays > 0 && (
                  <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                    <h3 className="text-lg font-semibold text-blue-900 mb-4">
                      Booking Summary
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between text-blue-800">
                        <span className="flex items-center">
                          <Clock className="h-5 w-5 mr-2" />
                          Duration
                        </span>
                        <span>{bookingData.totalDays} days</span>
                      </div>
                      <div className="flex justify-between text-blue-800">
                        <span className="flex items-center">
                          <CreditCard className="h-5 w-5 mr-2" />
                          Total Price
                        </span>
                        <span className="font-semibold">
                          ${bookingData.totalPrice}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="flex space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    fullWidth
                    onClick={() => navigate(`/cars/${carId}`)}
                  >
                    Back
                  </Button>
                  
                  <Button
                    type="submit"
                    variant="primary"
                    fullWidth
                    isLoading={isSubmitting}
                  >
                    Confirm Booking
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;