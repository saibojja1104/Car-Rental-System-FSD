import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import Loading from '../components/ui/Loading';
import { getCarById } from '../services/carService';

interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  price: number;
  description: string;
  imageUrl: string;
  features: string[];
}

export default function CarDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [car, setCar] = useState<Car | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCar = async () => {
      try {
        if (!id) throw new Error('Car ID is required');
        const carData = await getCarById(id);
        setCar(carData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load car details');
      } finally {
        setLoading(false);
      }
    };

    fetchCar();
  }, [id]);

  if (loading) return <Loading />;
  if (error) return <div className="text-center text-red-600 p-4">{error}</div>;
  if (!car) return <div className="text-center p-4">Car not found</div>;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="md:flex">
          <div className="md:flex-shrink-0">
            <img
              className="h-48 w-full object-cover md:h-full md:w-96"
              src={car.imageUrl}
              alt={`${car.make} ${car.model}`}
            />
          </div>
          <div className="p-8">
            <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold">
              {car.year} {car.make}
            </div>
            <h1 className="mt-2 text-3xl font-bold text-gray-900">
              {car.model}
            </h1>
            <p className="mt-4 text-xl text-gray-900">
              ${car.price.toLocaleString()} per day
            </p>
            <p className="mt-2 text-gray-600">
              {car.description}
            </p>
            
            <div className="mt-6">
              <h2 className="text-lg font-semibold text-gray-900">Features</h2>
              <ul className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2">
                {car.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-600">
                    <svg className="h-5 w-5 text-green-500 mr-2" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                      <path d="M5 13l4 4L19 7"></path>
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="mt-8 flex gap-4">
              <Button 
                onClick={() => navigate(`/booking/${car.id}`)}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Book Now
              </Button>
              <Button 
                onClick={() => navigate('/cars')}
                variant="outline"
              >
                Back to Cars
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}