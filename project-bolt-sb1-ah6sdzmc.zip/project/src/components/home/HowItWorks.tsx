import { Search, Calendar, Car, CheckCircle } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: <Search className="h-12 w-12 text-orange-500" />,
      title: 'Search for a Vehicle',
      description: 'Browse our extensive collection of vehicles and find the perfect match for your needs.'
    },
    {
      icon: <Calendar className="h-12 w-12 text-orange-500" />,
      title: 'Choose Dates',
      description: 'Select your pickup and return dates to check availability and get instant pricing.'
    },
    {
      icon: <Car className="h-12 w-12 text-orange-500" />,
      title: 'Book Your Car',
      description: 'Complete the booking process by providing your details and payment information.'
    },
    {
      icon: <CheckCircle className="h-12 w-12 text-orange-500" />,
      title: 'Enjoy Your Ride',
      description: 'Pick up your car at the designated location and start your journey with confidence.'
    }
  ];
  
  return (
    <section className="py-16 bg-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold sm:text-4xl">How It Works</h2>
          <p className="mt-4 text-xl text-blue-200 max-w-3xl mx-auto">
            Renting a car with DriveEasy is quick and hassle-free. Follow these simple steps:
          </p>
        </div>
        
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="relative text-center"
            >
              {/* Line connector between steps (except last item) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-full w-full h-0.5 bg-orange-500/50 -translate-y-1/2 -translate-x-6" />
              )}
              
              <div className="flex justify-center mb-4">
                <div className="flex items-center justify-center w-20 h-20 bg-blue-800 rounded-full">
                  {step.icon}
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-blue-200">{step.description}</p>
              
              {/* Step number indicator */}
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-lg border-4 border-blue-800">
                {index + 1}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;