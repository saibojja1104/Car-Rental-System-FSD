import { Link } from 'react-router-dom';
import { Car as CarType } from '../../services/carService';
import { Car, Fuel, Users, Gauge, ArrowRight } from 'lucide-react';
import Skeleton from '../ui/Skeleton';

interface FeaturedCarsProps {
  cars: CarType[];
  isLoading: boolean;
}

const FeaturedCars = ({ cars, isLoading }: FeaturedCarsProps) => {
  // Generate skeleton placeholders for loading state
  const skeletons = Array(6).fill(0).map((_, index) => (
    <div key={`skeleton-${index}`} className="bg-white rounded-lg shadow-md overflow-hidden">
      <Skeleton className="w-full h-48" />
      <div className="p-5">
        <Skeleton className="h-6 w-2/3 mb-2" />
        <Skeleton className="h-4 w-1/3 mb-4" />
        <div className="grid grid-cols-3 gap-2 mb-4">
          <Skeleton className="h-6 w-full" />
          <Skeleton className="h-6 w-full" />
          <Skeleton className="h-6 w-full" />
        </div>
        <Skeleton className="h-10 w-full" />
      </div>
    </div>
  ));
  
  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Featured Vehicles</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our selection of premium vehicles available for rent
          </p>
        </div>
        
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {isLoading ? (
            skeletons
          ) : cars.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Car className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-medium text-gray-900">No cars available</h3>
              <p className="mt-1 text-gray-500">Check back soon for our latest vehicles.</p>
            </div>
          ) : (
            cars.map((car) => (
              <div 
                key={car.id}
                className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg hover:translate-y-[-4px]"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={car.imageUrls[0] || 'https://images.pexels.com/photos/1213294/pexels-photo-1213294.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'}
                    alt={`${car.make} ${car.model}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-orange-500 text-white text-sm font-semibold px-3 py-1 rounded-full">
                    ${car.dailyRate}/day
                  </div>
                </div>
                
                <div className="p-5">
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    {car.make} {car.model}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">{car.year} • {car.category}</p>
                  
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <div className="flex items-center text-gray-600 text-sm">
                      <Fuel className="h-4 w-4 mr-1" />
                      {car.fuelType}
                    </div>
                    <div className="flex items-center text-gray-600 text-sm">
                      <Users className="h-4 w-4 mr-1" />
                      {car.seats} Seats
                    </div>
                    <div className="flex items-center text-gray-600 text-sm">
                      <Gauge className="h-4 w-4 mr-1" />
                      {car.transmission}
                    </div>
                  </div>
                  
                  <Link
                    to={`/cars/${car.id}`}
                    className="flex items-center justify-center w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-800 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300"
                  >
                    View Details
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="mt-10 text-center">
          <Link
            to="/cars"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition-all duration-300"
          >
            View All Vehicles
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedCars;