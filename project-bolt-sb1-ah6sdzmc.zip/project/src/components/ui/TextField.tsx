import { InputHTMLAttributes } from 'react';

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
}

const TextField = ({
  label,
  error,
  fullWidth = true,
  ...props
}: TextFieldProps) => {
  const widthClass = fullWidth ? 'w-full' : '';
  const errorClass = error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-orange-500 focus:border-orange-500';
  
  return (
    <div className={widthClass}>
      {label && (
        <label 
          htmlFor={props.id} 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          {label}
        </label>
      )}
      
      <input
        className={`block ${widthClass} rounded-md shadow-sm py-2 px-3 bg-white ${errorClass} focus:outline-none focus:ring-2 focus:ring-opacity-50 sm:text-sm transition-colors duration-200`}
        {...props}
      />
      
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
};

export default TextField;