import React from 'react';
import { Car } from 'lucide-react';

interface LoadingProps {
  size?: 'sm' | 'md' | 'lg';
  message?: string;
}

const Loading = ({ size = 'md', message = 'Loading...' }: LoadingProps) => {
  const sizeClasses = {
    sm: 'h-8 w-8',
    md: 'h-12 w-12',
    lg: 'h-16 w-16'
  };
  
  return (
    <div className="flex flex-col items-center justify-center h-60">
      <div className="relative">
        <Car className={`${sizeClasses[size]} text-orange-500 animate-bounce`} />
        <div className="absolute inset-0 border-t-4 border-blue-800 rounded-full animate-spin opacity-25"></div>
      </div>
      <p className="mt-4 text-gray-600 font-medium">{message}</p>
    </div>
  );
};

export default Loading;