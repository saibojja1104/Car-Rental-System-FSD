import { Link } from 'react-router-dom';
import { 
  Car, 
  Facebook, 
  Twitter, 
  Instagram, 
  MapPin, 
  Phone, 
  Mail, 
  ArrowRight 
} from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  const socialLinks = [
    { icon: <Facebook className="h-5 w-5" />, href: '#', ariaLabel: 'Facebook' },
    { icon: <Twitter className="h-5 w-5" />, href: '#', ariaLabel: 'Twitter' },
    { icon: <Instagram className="h-5 w-5" />, href: '#', ariaLabel: 'Instagram' }
  ];
  
  const quickLinks = [
    { name: 'About Us', href: '/about' },
    { name: 'Cars', href: '/cars' },
    { name: 'Locations', href: '/locations' },
    { name: 'FAQs', href: '/faqs' },
    { name: 'Terms & Conditions', href: '/terms' },
    { name: 'Privacy Policy', href: '/privacy' }
  ];
  
  return (
    <footer className="bg-blue-900 text-white">
      {/* Main footer content */}
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and about */}
          <div>
            <Link to="/" className="flex items-center">
              <Car className="h-8 w-8 text-orange-500" />
              <span className="ml-2 text-xl font-bold">DriveEasy</span>
            </Link>
            <p className="mt-4 text-blue-200">
              Experience the freedom of the road with our premium car rental service.
              We offer a wide range of vehicles to suit every need and budget.
            </p>
            <div className="mt-6 flex space-x-4">
              {socialLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="text-blue-200 hover:text-orange-500 transition-colors duration-200"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={link.ariaLabel}
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>
          
          {/* Quick links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-blue-200 hover:text-orange-500 transition-colors duration-200 flex items-center"
                  >
                    <ArrowRight className="h-4 w-4 mr-2" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-orange-500 mr-3 mt-1 flex-shrink-0" />
                <span className="text-blue-200">
                  123 Rental Street, Car City<br />
                  Stateville, 12345
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-orange-500 mr-3 flex-shrink-0" />
                <a href="tel:+11234567890" className="text-blue-200 hover:text-orange-500 transition-colors duration-200">
                  +1 (123) 456-7890
                </a>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-orange-500 mr-3 flex-shrink-0" />
                <a href="mailto:info@driveeasy.com" className="text-blue-200 hover:text-orange-500 transition-colors duration-200">
                  info@driveeasy.com
                </a>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Newsletter</h3>
            <p className="text-blue-200 mb-4">
              Subscribe to our newsletter for the latest updates and offers.
            </p>
            <form className="mt-2">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="px-4 py-2 w-full text-gray-800 bg-white rounded-l-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                  required
                />
                <button
                  type="submit"
                  aria-label="Subscribe"
                  className="bg-orange-500 text-white px-4 py-2 rounded-r-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors duration-200"
                >
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      
      {/* Bottom footer */}
      <div className="bg-blue-950 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="text-sm text-blue-300 text-center md:text-left">
              © {currentYear} DriveEasy. All rights reserved.
            </div>
            <div className="mt-4 md:mt-0 text-sm text-blue-300 text-center md:text-right">
              <span>Designed & Developed by StackBlitz</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;